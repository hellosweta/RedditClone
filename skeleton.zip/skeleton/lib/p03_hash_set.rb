require_relative 'p02_hashing'

class HashSet
  attr_reader :count

  def initialize(num_buckets = 8)
    @store = Array.new(num_buckets) { Array.new }
    @count = 0
  end

  def insert(num) # O(1)
    resize! if num_buckets == @count
    hash_num = num.hash
    index = hash_num % num_buckets
    @store[index] << num
    @count += 1
  end

  def remove(num) #O(1)
    hash_num = num.hash
    index = hash_num % num_buckets
    @store[index].delete(num)
  end

  def include?(num) #O(1)
    hash_num = num.hash
    index = hash_num % num_buckets
    @store[index].include?(num)
  end

  private

  def [](num)
    # optional but useful; return the bucket corresponding to `num`
  end

  def num_buckets
    @store.length
  end

  def resize! #O(n)
    clone = @store.dup
    @store = Array.new(num_buckets * 2) {Array.new}
    @count = 0
    clone.each do |bucket| # our bucket element usually has one worst case hash 2 -3
      bucket.each do |el|
        insert(el)
      end
    end
  end
end
