require "byebug"

class Link
  attr_accessor :key, :val, :next, :prev

  def initialize(key = nil, val = nil)
    @key = key
    @val = val
    @next = nil
    @prev = nil
  end

  def to_s
    "#{@key}: #{@val}"
  end

  def remove
    # optional but useful, connects previous link to next link
    # and removes self from list.
  end
end

class LinkedList
  include(Enumerable)
  attr_accessor :tail, :head

  def initialize
    @head = Link.new
    @tail = Link.new
    @head.next = @tail
    @tail.prev = @head
  end

  def [](i)
    each_with_index { |link, j| return link if i == j }
    nil
  end

  def first
    @head.next
  end

  def last
    @tail.prev
  end

  def empty?
    # debugger
    @head.next == @tail && @tail.prev == @head
  end

  def get(key)
    current_link = @head

    until current_link.key == key || current_link == @tail
      current_link = current_link.next
    end

    current_link.val
  end

  def include?(key)
    current_link = @head
    until current_link.key == key || current_link == @tail
      current_link = current_link.next
    end
      return true if current_link.key == key
      false
  end

  def append(key, val)
    link = Link.new(key, val)
    link.prev = @tail.prev
    @tail.prev.next = link
    @tail.prev = link
    link.next = @tail

  end

  def update(key, val)
    current_link = @head
    until current_link.key == key || current_link == @tail
      current_link = current_link.next
    end
    current_link.val = val
  end

  def remove(key) #O(n)
    current_link = @head
    until current_link.key == key || current_link == @tail
      current_link = current_link.next
    end
    if current_link.key == key
      current_link.next.prev = current_link.prev
      current_link.prev.next = current_link.next
    end

  end

  def each
    current_link = @head
    until current_link == @tail.prev
      current_link = current_link.next
      yield(current_link)
    end
  end

  # uncomment when you have `each` working and `Enumerable` included
  def to_s
    inject([]) { |acc, link| acc << "[#{link.key}, #{link.val}]" }.join(", ")
  end
end
